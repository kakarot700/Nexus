# NEXUS AI DEVELOPMENT CONSTITUTION

## Mission
NEXUS is an AI problem-solving engine. It turns an ambiguous real-world problem into structured evidence, explicit constraints, multiple solution strategies, evaluation, and an interactive prototype.

Core flow:
Problem → Evidence → Constraints → Solutions → Evaluation → Prototype → Decision

## Mandatory workflow
Before changing code:
1. Read this file.
2. Read the relevant product/design/engineering documentation.
3. Inspect the existing implementation.
4. Reuse existing patterns before creating new ones.
5. State a concise implementation plan for non-trivial changes.
6. Implement the smallest coherent change.
7. Validate the result, including the rendered UI for UI work.

## Product rules
NEXUS must not become a generic chatbot, AI wrapper, SaaS dashboard, Discord clone, AI marketplace, CRUD application, or feature-card collection.

Every feature must strengthen the core problem-solving flow.

## Design rules
Avoid generic AI aesthetics:
- purple AI gradients
- excessive glassmorphism
- giant rounded cards
- decorative statistics
- gradient text
- glowing AI orbs
- robot illustrations
- excessive pills
- random icons
- unnecessary shadows
- dashboard sidebars
- decorative particles
- animation without meaning

Do not invent a new visual language when a documented design rule exists.

## Engineering rules
Prefer:
- strict TypeScript
- small cohesive components
- explicit domain models
- validated boundaries
- provider-independent AI logic
- progressive enhancement
- graceful failure
- accessible semantic HTML
- mobile-first implementation
- minimal dependencies

Avoid:
- unnecessary libraries
- duplicated logic
- giant components
- hidden global state
- magic values
- speculative abstractions
- unrelated refactors

## AI rules
Model output is untrusted input.

Every structured model response must be:
1. parsed
2. schema validated
3. normalized
4. sanity checked
5. rendered safely

Never present an AI assumption as a known fact.

Use evidence states:
- USER_PROVIDED
- DERIVED
- PROPOSED
- UNVERIFIED

## Mobile requirement
Primary device is a phone.

Validate at:
- 360px
- 375px
- 390px
- 412px

No horizontal scrolling. Touch targets must be comfortable. Important workflows must remain usable with a mobile keyboard open.

## No fake functionality
Never ship buttons or controls that only look functional. If a capability is unavailable, provide a real fallback or clearly expose the limitation.

## Definition of done
A feature is complete only when its relevant behavior, loading, empty, error, success, accessibility, responsive behavior, tests, and console state have been checked.

## Uncertainty
Do not invent product decisions. Check the documentation first. If still unspecified, choose the smallest coherent behavior and document the decision.
