# NEXUS MOTION

## Purpose
Motion communicates state and spatial relationships.

## Appropriate
- stage transitions
- expanding details
- solution graph changes
- progressive AI output
- prototype transitions
- focus feedback

## Avoid
- constant floating
- decorative particles
- excessive bouncing
- animation on every element
- long blocking transitions

## Accessibility
Respect reduced-motion preferences.

Animation must never be required to understand content.
