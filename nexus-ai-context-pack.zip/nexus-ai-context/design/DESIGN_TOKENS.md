# NEXUS DESIGN TOKENS

The exact visual values may evolve, but all UI should consume centralized tokens rather than scattered literals.

## Spacing
--space-1: 4px
--space-2: 8px
--space-3: 12px
--space-4: 16px
--space-5: 20px
--space-6: 24px
--space-8: 32px
--space-10: 40px
--space-12: 48px
--space-16: 64px
--space-20: 80px

## Radius
Use a restrained radius scale. Do not make every element maximally rounded.

## Color
Define semantic tokens for:
- background
- surface
- elevated surface
- text
- muted text
- border
- focus
- success
- warning
- error
- evidence states

Do not hardcode repeated colors inside components.

## Typography
Centralize:
- font families
- display sizes
- heading sizes
- body sizes
- labels
- line heights
- weights

## Rule
Components consume tokens. They should not invent their own mini design systems.
