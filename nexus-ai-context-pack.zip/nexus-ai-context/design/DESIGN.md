# NEXUS DESIGN SYSTEM

## Design thesis
NEXUS should feel like a sophisticated instrument for thinking.

Priorities:
1. hierarchy
2. clarity
3. information density
4. spatial rhythm
5. typography
6. interaction quality

Decoration is secondary.

## Visual language
Combine:
- editorial typography
- scientific-instrument clarity
- restrained premium interaction design
- structured information visualization

## Layout
Use deliberate spacing:
4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80.

Do not invent arbitrary spacing values without reason.

## Containers
Prefer full-width compositions, constrained reading widths, deliberate whitespace, and clear alignment.

Do not wrap every element in a card.

## Cards
A card must represent a real conceptual object such as:
- solution
- constraint
- evidence item
- prototype
- decision

Do not create cards just to group unrelated text.

## Typography
Use a consistent display/body typography system. Typography must create hierarchy rather than decoration.

## Color
Color communicates meaning. Use semantic color for states and avoid decorative color noise.

## Borders and shadows
Prefer subtle borders, hairlines, spacing, and typography for structure. Shadows should be rare.

## Motion
Motion explains state change. Avoid perpetual or decorative animation.

## Icons
Use one coherent icon family. Icons must have a semantic purpose.

## Forbidden generic AI patterns
- purple AI gradient
- glowing orb
- robot illustration
- sparkle decoration
- "AI POWERED" badge
- excessive glassmorphism
- excessive pill controls
- giant gradient hero
- dashboard-like sidebar by default

## Product identity
The Solution Graph is a central visual object:
Problem
↓
Constraints
↓
Possible solutions
↓
Evaluation
↓
Selected direction
↓
Prototype
