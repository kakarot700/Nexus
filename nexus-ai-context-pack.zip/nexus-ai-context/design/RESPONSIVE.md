# NEXUS RESPONSIVE RULES

## Primary target
Phone-first.

Required validation widths:
360px
375px
390px
412px

Secondary:
768px
1280px

## Mobile rules
- no horizontal scrolling
- controls remain reachable
- readable text without zoom
- comfortable touch targets
- important information appears in a logical order
- keyboard opening must not break the primary flow

## Scaling
Do not simply shrink desktop layouts.

Recompose layouts when necessary.

## Desktop
Use additional space to improve comprehension, not to create empty decorative regions.
