# NEXUS COMPONENT RULES

## Principle
Components represent concepts, not arbitrary boxes.

Before creating a component ask:
"What concept does this represent?"

## Hierarchy

### Primitives
Button, Input, Text, Divider, Icon, Tooltip.

### Interface
ProblemInput, ConstraintItem, EvidenceBadge, SolutionItem, EvaluationRow.

### Product
ProblemMap, SolutionGraph, SolutionComparison, DecisionTrail, PrototypePreview.

## Reuse
Search for an existing component before creating a new one.

Do not duplicate visually equivalent components.

## Buttons
Provide:
- clear label
- focus state
- disabled state where relevant
- loading state where relevant
- adequate touch area

## Loading
Communicate actual progress when possible.

## Empty states
Explain what is missing and what the user can do next.

## Errors
Explain:
1. what happened
2. whether work is preserved
3. what to do next

## Card nesting
Avoid deep card nesting. Prefer spacing, typography, and dividers.

## Component smell
A component handling API requests, AI orchestration, business rules, state management, and complex rendering simultaneously is probably too large.
