# NEXUS UI COPY

## Voice
Precise, calm, direct.

Avoid:
- hype
- meaningless AI jargon
- excessive exclamation marks
- fake certainty
- marketing language inside functional controls

## Prefer
"Analyze problem"
"Review constraints"
"Generate approaches"
"Stress-test solutions"
"Build prototype"
"Needs verification"

## Avoid
"Supercharge"
"Magic AI"
"Unlock the future"
"10x your ideas"
"AI-powered magic"

Functional UI should explain what will happen.
