# NEXUS ACCESSIBILITY

## Baseline
Use semantic HTML.

## Keyboard
All interactive controls must be reachable and visibly focused.

## Labels
Inputs require accessible labels.

## Contrast
Do not use low-contrast text for aesthetic reasons.

## Motion
Respect prefers-reduced-motion.

## Errors
Errors should be associated with the relevant control or stage.

## Status
AI progress and important status changes should be understandable without relying solely on color.

## Touch
Interactive targets must be comfortable on a phone.
