# NEXUS PROTOTYPE ENGINE

## Purpose
Create a small interactive vertical slice of the selected solution.

## Principle
A prototype demonstrates the mechanism. It does not need to implement the entire imagined product.

## Required output
- prototype name
- purpose
- screens
- core interaction
- required data
- known limitations

## Safety rule
Generated prototype specifications must be validated before being converted into application UI.

## Quality rule
Prefer one believable interaction over ten fake features.
