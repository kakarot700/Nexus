# NEXUS EVALUATION ENGINE

## Purpose
Turn vague "AI judgment" into explicit constraint-aware reasoning.

## Criteria
- constraint compatibility
- feasibility
- impact
- accessibility
- implementation complexity
- risk

## Evaluation statuses
PASS: evidence supports compatibility.
PARTIAL: some requirements are satisfied or uncertainty remains.
FAIL: a known requirement is violated.
UNKNOWN: insufficient evidence.

## Important rule
Do not fabricate numerical precision.

A model saying "87% feasible" is not inherently meaningful. Prefer explicit evidence and explanations.

## Comparison
The engine should expose:
- strengths
- weaknesses
- failed constraints
- unresolved assumptions
- missing information

The user should be able to understand why a solution is promising without trusting an unexplained score.
