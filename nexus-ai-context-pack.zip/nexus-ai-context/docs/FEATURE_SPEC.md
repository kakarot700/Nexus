# NEXUS FEATURE SPECIFICATION

## P0: Core experience
- Problem input
- Problem analysis
- Stakeholder extraction
- Evidence classification
- Constraint extraction
- Multiple solution generation
- Critique
- Constraint-aware evaluation
- Solution Graph
- Decision Trail
- Prototype vertical slice

## P1: Quality
- streaming progress
- retry/fallback
- export/shareable result
- accessible interactions
- mobile optimization
- resilient error states

## P2: Optional
Only add after P0 is stable:
- saved sessions
- comparison history
- richer prototype generation
- additional model providers

## Explicitly avoid
Auth, profiles, social feeds, chat, payments, notifications, admin dashboards, analytics dashboards, model marketplaces, and large integration collections unless a later product requirement makes one essential.

## Feature gate
Before adding a feature answer:
- Which stage of the NEXUS pipeline does it improve?
- What user problem does it solve?
- Can the same outcome be achieved more simply?
- Does it increase complexity enough to justify itself?
