# NEXUS HACKATHON MODE

## Principle
The hackathon submission must be adapted to the official challenge theme and rules.

Do not assume a generic prebuilt feature automatically satisfies the event.

## Before implementation
Verify:
- official theme
- eligibility
- pre-existing work rules
- allowed tools/services
- submission format
- judging criteria
- deadline and timezone
- demo requirements

## Theme adaptation
Keep the NEXUS engine reusable, but make the final problem, constraints, solution, and prototype clearly relevant to the announced theme.

## Submission quality
The final project should have:
- working live demo when possible
- public/reviewable code where required
- short focused demo video
- clear problem statement
- clear innovation
- architecture explanation
- screenshots
- documented limitations

## Rule
Never misrepresent pre-hackathon work as work created during the event.
