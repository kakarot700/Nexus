# NEXUS USER FLOWS

## Primary flow
Landing/Input
→ Problem analysis
→ Problem map
→ Constraints and evidence
→ Solution generation
→ Solution comparison
→ Evaluation
→ Select direction
→ Prototype
→ Decision trail

## First-use principle
The user should reach the first meaningful insight quickly. Do not force account creation, configuration, or unnecessary onboarding before the core experience.

## Loading behavior
Long AI work should expose meaningful stages rather than a meaningless spinner.

Example:
Analyzing problem
→ Mapping constraints
→ Generating approaches
→ Stress-testing approaches
→ Preparing prototype

## Failure behavior
Preserve all completed work. Identify the failed stage. Offer retry and, where available, provider fallback.

## Back behavior
Going backward must not silently destroy completed analysis.
