# NEXUS PRODUCT PRINCIPLES

1. Structure beats verbosity.
2. Constraints are first-class data.
3. Uncertainty must be visible.
4. Different solutions must actually be different.
5. Every conclusion should have a traceable reason.
6. AI proposes; the system validates and the user decides.
7. The smallest useful prototype beats a giant fake product.
8. Every interface element must earn its space.
9. Mobile is a primary environment, not an afterthought.
10. Reliability beats spectacle.
11. A failed AI request must not destroy user work.
12. Prefer explainable state transitions over magical behavior.
