# NEXUS DEMO SCRIPT

Target duration: approximately 2–3 minutes.

## 0:00–0:15
State the problem with a concrete example.

Thesis:
"Most AI systems answer problems. NEXUS works through them."

## 0:15–0:35
Enter the problem.

## 0:35–0:55
Show the Problem Map:
- stakeholders
- goals
- evidence
- unknowns
- constraints

## 0:55–1:15
Generate genuinely different solution approaches.

## 1:15–1:35
Stress-test and evaluate the approaches.

Show why a solution passes, partially passes, or fails specific constraints.

## 1:35–1:55
Select a direction and generate the prototype.

## 1:55–2:15
Interact with the prototype.

## 2:15–2:30
Show the Decision Trail and uncertainty labels.

Closing idea:
"NEXUS doesn't just generate ideas. It turns constraints into a path toward a solution."

## Demo rules
Never demo a feature that has not been tested.
Keep a deterministic fallback/demo scenario available if the live model provider fails.
