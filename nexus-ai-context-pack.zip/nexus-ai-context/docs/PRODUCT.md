# NEXUS PRODUCT

## One sentence
NEXUS turns an ambiguous real-world problem into a structured, evaluated, explainable solution and an interactive prototype.

## Thesis
Most AI interfaces optimize for generating answers. Real-world problems contain stakeholders, incomplete information, constraints, competing objectives, uncertainty, and implementation difficulty.

NEXUS treats problem solving as a process.

## Core pipeline
1. Problem: accept a natural-language problem.
2. Evidence: separate supplied information, derived information, proposals, and unknowns.
3. Constraints: identify cost, time, infrastructure, user, accessibility, privacy, geography, and other constraints.
4. Solutions: generate genuinely different approaches.
5. Evaluation: test approaches against explicit criteria and constraints.
6. Prototype: create a small interactive vertical slice.
7. Decision: expose the reasoning trail and remaining uncertainty.

## Primary user
A person facing a complex real-world problem who needs structured thinking rather than another generic chatbot answer.

## Product personality
Intelligent, calm, precise, exploratory, transparent, technically sophisticated.

Not childish, flashy, corporate, gamer-oriented, or futuristic for decoration's sake.

## Core success test
A first-time user should understand the difference between NEXUS and a normal chatbot within one minute.

## Non-goals
- social network
- general-purpose chatbot
- AI model marketplace
- agent directory
- project-management system
- enterprise dashboard
- knowledge-base product
