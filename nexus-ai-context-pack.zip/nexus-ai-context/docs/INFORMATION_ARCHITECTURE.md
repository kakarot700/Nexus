# NEXUS INFORMATION ARCHITECTURE

## Primary objects
Problem
Evidence
Stakeholder
Constraint
Solution
Evaluation
Decision
Prototype

## Primary surfaces
1. Problem Input
2. Problem Map
3. Solution Workspace
4. Evaluation
5. Prototype
6. Decision Trail

## Navigation principle
Navigation should reflect the problem-solving workflow, not a generic application dashboard.

Avoid persistent navigation that exists only because dashboards commonly have sidebars.
