# NEXUS AI SYSTEM

## Logical pipeline
Problem Interpreter
→ Constraint Extractor
→ Solution Generator
→ Critic
→ Evaluation Engine
→ Prototype Agent
→ Explanation Layer

These are logical roles, not necessarily separate models.

## Problem Interpreter
Extract:
- problem statement
- context
- stakeholders
- goals
- evidence
- unknowns
- assumptions
- ambiguity

Never invent facts.

## Constraint Extractor
Identify:
- cost
- time
- technology
- infrastructure
- geography
- users
- accessibility
- privacy
- regulation
- reliability
- environmental factors

Every constraint has a source.

## Solution Generator
Generate 3–5 genuinely different approaches. Vary the mechanism, not just the wording.

Strategy classes:
- SOFTWARE
- HUMAN_SOFTWARE
- INFRASTRUCTURE
- BEHAVIORAL
- HYBRID

## Critic
Try to break each solution:
- weakest assumption
- violated constraint
- failure modes
- missing information
- excluded users
- implementation difficulty

## Evaluation
Evaluate explicit criteria:
- constraint compatibility
- feasibility
- impact
- accessibility
- implementation complexity
- risk

Use PASS/PARTIAL/FAIL/UNKNOWN where appropriate. Explain every result.

## Evidence model
USER_PROVIDED = directly supplied
DERIVED = inferred from supplied information
PROPOSED = AI-generated proposal
UNVERIFIED = requires external verification

## Provider abstraction
The application must not depend directly on one model provider. Keep provider selection behind an AI interface so free/sponsor/fallback providers can be swapped without rewriting the product.

## Reliability
On failure:
- preserve user input
- preserve completed stages
- identify failed stage
- retry
- fallback when available
