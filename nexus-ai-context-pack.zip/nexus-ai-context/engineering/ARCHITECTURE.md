# NEXUS ARCHITECTURE

## Preferred stack
- Next.js
- TypeScript
- React
- Tailwind CSS
- Vercel-compatible deployment
- runtime schema validation
- AI provider abstraction

## Layers

### Presentation
Screens, components, interaction, accessibility, responsive layout.

### Application
Workflows, orchestration, state transitions, user actions.

### Domain
Problem, Evidence, Constraint, Solution, Evaluation, Decision, Prototype.

### AI
Provider calls, prompts, structured outputs, retries, fallback, streaming.

The UI must not directly own provider-specific logic.

## AI interface

```ts
interface AIProvider {
  analyzeProblem(input: string): Promise<ProblemAnalysis>;
  generateSolutions(input: ProblemAnalysis): Promise<Solution[]>;
  evaluateSolutions(
    problem: ProblemAnalysis,
    solutions: Solution[]
  ): Promise<Evaluation[]>;
  generatePrototype(
    problem: ProblemAnalysis,
    solution: Solution
  ): Promise<Prototype>;
}
```

## Workflow state

Prefer explicit stages:

```ts
type NexusStage =
  | "INPUT"
  | "ANALYZING"
  | "CONSTRAINTS"
  | "SOLUTIONS"
  | "EVALUATING"
  | "PROTOTYPE"
  | "COMPLETE"
  | "ERROR";
```

## Persistence
Do not add a database unless a real requirement needs it.

## Dependencies
Before adding one:
1. explain why it is needed
2. check existing dependencies
3. consider native alternatives
4. consider bundle size and mobile performance

## Principle
Complexity must earn its place.
