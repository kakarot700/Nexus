# NEXUS TESTING

## Required levels

### Unit
Test domain logic, validation, normalization, and deterministic evaluation rules.

### Integration
Test AI boundary handling, retries, schema validation, and workflow transitions.

### UI
Test primary user flow and important states.

### Browser
Where tooling permits, test the rendered application at mobile and desktop sizes.

## Critical cases
- valid problem
- empty input
- malformed AI output
- AI timeout
- provider failure
- fallback provider
- retry
- long text
- no solutions
- partial evaluation
- mobile keyboard
- narrow viewport

## Rule
A test must verify behavior, not merely that code executes.
