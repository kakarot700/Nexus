# NEXUS CODE STANDARDS

## TypeScript
Use strict TypeScript. Avoid `any` unless there is a documented boundary reason.

## Components
Keep components cohesive. Separate rendering from domain logic and provider calls.

## Naming
Use descriptive names:
ProblemInput
ConstraintList
SolutionGraph
EvaluationPanel
DecisionTrail

Avoid:
Thing
Box
Card2
AIThing
NewComponent

## Functions
Prefer small composable functions.

## Errors
Never silently swallow errors.

## Comments
Explain why, not obvious mechanics.

## Hygiene
Before completion remove:
- unused imports
- debug logs
- dead code
- abandoned experiments
- commented-out implementations

## Consistency
Follow the repository formatter, linter, and existing conventions.
