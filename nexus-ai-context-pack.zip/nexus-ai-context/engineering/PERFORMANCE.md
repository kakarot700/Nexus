# NEXUS PERFORMANCE

## Primary constraint
The application must remain usable on a phone.

## Rules
- minimize client JavaScript
- avoid unnecessary dependencies
- lazy-load heavy features
- avoid unnecessary re-renders
- stream long AI results when beneficial
- avoid rendering huge hidden trees
- optimize images
- keep initial interaction fast

## AI
Do not request unnecessarily large outputs.

Prefer structured concise intermediate results.

## Measurement
When performance work is requested, measure before and after rather than guessing.
