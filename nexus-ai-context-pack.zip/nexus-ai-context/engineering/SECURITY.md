# NEXUS SECURITY

## Principles
Treat all external input as untrusted.

## AI output
Validate model output before use.

## Secrets
Never place provider secrets in client-side code or commit secrets.

## Rendering
Escape or safely render user/model-generated content.

## Requests
Validate inputs at API boundaries.

## Errors
Do not expose internal stack traces, secrets, or provider credentials to users.

## Dependencies
Keep dependencies minimal and maintained.

## Logging
Never log credentials or sensitive user content unnecessarily.
