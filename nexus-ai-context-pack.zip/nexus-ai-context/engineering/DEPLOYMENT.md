# NEXUS DEPLOYMENT

## Target
A simple Vercel-compatible deployment is preferred for the hackathon unless requirements demand otherwise.

## Environment variables
Document required variables without committing values.

## Production checks
Before deployment:
- typecheck
- lint
- tests
- production build
- inspect primary route
- inspect AI failure behavior
- inspect mobile layout

## Deployment principle
The deployed build must represent the same tested commit.

## Rollback
Keep deployment history and know which commit is live.
