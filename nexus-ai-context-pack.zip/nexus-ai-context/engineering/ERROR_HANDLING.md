# NEXUS ERROR HANDLING

## Error categories
- validation
- network
- provider
- schema
- application
- unexpected

## User-facing errors
State:
1. what happened
2. whether work was preserved
3. what action is available

## Recovery
Prefer:
retry
fallback
resume
safe reset

over:
blank screen
silent failure
lost state

## Developer diagnostics
Keep useful internal diagnostics without exposing secrets or implementation details to users.
