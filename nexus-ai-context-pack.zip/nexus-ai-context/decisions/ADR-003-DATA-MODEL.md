# ADR-003: DOMAIN MODEL

## Decision
Use explicit domain objects:
Problem, Evidence, Stakeholder, Constraint, Solution, Evaluation, Decision, Prototype.

## Reason
The product's differentiator is structured problem solving. These concepts must exist explicitly rather than being hidden inside arbitrary model text.

## Status
Accepted
