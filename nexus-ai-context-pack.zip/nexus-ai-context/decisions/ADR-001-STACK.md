# ADR-001: STACK

## Decision
Use a TypeScript/React/Next.js architecture with Vercel-compatible deployment.

## Reason
The project needs rapid iteration, strong component composition, mobile responsiveness, and straightforward deployment.

## Constraint
Avoid adding infrastructure that does not directly improve the hackathon experience.

## Status
Accepted
