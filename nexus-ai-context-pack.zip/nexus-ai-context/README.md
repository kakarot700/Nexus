# NEXUS AI CONTEXT PACK

This directory contains the permanent product, design, engineering, AI, and quality context for NEXUS.

## How to use

Copy the contents of this directory into the root of the NEXUS repository.

The most important file is:

`AGENTS.md`

Coding agents should read it before making changes.

For a specific task, provide the agent with the relevant documentation path rather than pasting the entire context pack into the chat.

## Recommended agent instruction

Read `AGENTS.md` and the relevant project documentation before changing code. Inspect the existing implementation first. Follow the repository's product, design, architecture, and engineering rules. Implement the smallest coherent change, then validate it.

## Source of truth hierarchy

1. Official hackathon rules, where applicable
2. Product requirements
3. Design system
4. Architecture decisions
5. Engineering standards
6. Task-specific instructions

If a lower-level instruction conflicts with an official rule, follow the official rule.

## Important

This pack is documentation, not application source code. It should guide coding agents and remain version-controlled with the project.
