# NEXUS AI BUILD PROTOCOL

You are working on an existing engineered product, not a blank canvas.

## Phase 1: Understand
Before coding:
1. read AGENTS.md
2. read relevant documentation
3. inspect repository structure
4. inspect existing implementation
5. identify reusable components
6. identify constraints

Do not immediately write code.

## Phase 2: Plan
For non-trivial work, state:
- goal
- files to modify
- new files, if genuinely required
- architectural fit
- risks

Keep it concise.

## Phase 3: Implement
Implement the smallest coherent version.

Do not:
- refactor unrelated code
- redesign unrelated screens
- add speculative features
- replace working libraries without reason
- rewrite the project unnecessarily

## Phase 4: Validate
Run appropriate:
- typecheck
- lint
- tests
- build
- browser/UI checks

For UI work, inspect the rendered result at required mobile widths.

## Phase 5: Self-critique
Ask:
- Did I solve the requested problem?
- Does it look like NEXUS?
- Did I introduce unnecessary complexity?
- What happens when something fails?
- Does it work on a phone?
- Did I turn assumptions into facts?

## Phase 6: Report
Return:
- what changed
- files changed
- validation performed
- issues discovered
- remaining limitations

Never claim a test was run if it was not run.
