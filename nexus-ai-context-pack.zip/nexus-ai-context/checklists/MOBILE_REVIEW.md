# NEXUS MOBILE REVIEW

Primary target: Android phone.

## Test
- [ ] 360px
- [ ] 375px
- [ ] 390px
- [ ] 412px

## Check
- [ ] no horizontal scroll
- [ ] readable text
- [ ] touch targets comfortable
- [ ] input remains visible when keyboard opens
- [ ] buttons do not become cramped
- [ ] graphs remain understandable
- [ ] long content does not create unusable nested scroll areas
- [ ] loading and errors remain understandable
- [ ] important actions are reachable by thumb

## Principle
Do not merely shrink the desktop UI. Recompose it for mobile.
