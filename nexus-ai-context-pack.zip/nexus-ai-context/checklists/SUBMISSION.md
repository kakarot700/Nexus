# NEXUS SUBMISSION CHECKLIST

Before submitting to a hackathon:

- [ ] Verify official rules
- [ ] Verify eligibility
- [ ] Verify pre-existing-work restrictions
- [ ] Verify theme requirements
- [ ] Verify allowed services/tools
- [ ] Verify deadline and timezone
- [ ] Verify judging criteria
- [ ] Verify required submission fields
- [ ] Test live URL
- [ ] Test demo from a clean browser
- [ ] Record demo video
- [ ] Prepare screenshots
- [ ] Confirm repository visibility/access
- [ ] Confirm README explains architecture and setup
- [ ] Document limitations honestly
- [ ] Do not claim unverified functionality
- [ ] Do not misrepresent pre-hackathon work
