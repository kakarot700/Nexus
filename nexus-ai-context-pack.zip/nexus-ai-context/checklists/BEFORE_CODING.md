# BEFORE CODING

- [ ] Read AGENTS.md
- [ ] Identify the relevant product specification
- [ ] Identify relevant design rules
- [ ] Inspect existing code
- [ ] Search for reusable components/utilities
- [ ] Define the smallest coherent change
- [ ] Identify risks
- [ ] Confirm the change belongs to the product
