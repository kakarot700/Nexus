# NEXUS UI REVIEW

Render the actual application. Do not review only source code.

## Viewports
360 × 800
390 × 844
768 × 1024
1280 × 800

## First five seconds
- [ ] Is this clearly NEXUS?
- [ ] Is the primary action obvious?
- [ ] Is hierarchy understandable?
- [ ] Does the interface feel intentional?

## Visual quality
Inspect:
- typography
- spacing
- alignment
- density
- borders
- radius
- color
- icon consistency
- interaction states

## Anti-pattern scan
Flag:
- purple AI gradients
- excessive rounded rectangles
- unexplained card grids
- decorative statistics
- giant empty hero
- random illustrations
- excessive glass effects
- inconsistent icons
- excessive animation
- cramped mobile layout

## Interaction
Test:
- primary flow
- back navigation
- retry
- loading
- errors
- empty states
- long AI responses
- slow network
- mobile keyboard

## Quality question
Does every visible decision look deliberate?
