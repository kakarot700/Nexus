# NEXUS PRE-PR CHECKLIST

## Product
- [ ] Strengthens the core NEXUS experience
- [ ] User outcome is clear
- [ ] No generic-chatbot drift
- [ ] No fake functionality

## Design
- [ ] Follows DESIGN.md
- [ ] Intentional spacing
- [ ] Clear hierarchy
- [ ] No unnecessary cards
- [ ] No unnecessary pills
- [ ] No decorative gradients
- [ ] Consistent iconography

## Mobile
- [ ] 360px
- [ ] 375px
- [ ] 390px
- [ ] 412px
- [ ] no horizontal scrolling
- [ ] controls are touch-friendly
- [ ] keyboard does not break flow

## AI
- [ ] schema validation
- [ ] safe normalization
- [ ] retry
- [ ] fallback if available
- [ ] user work preserved
- [ ] uncertainty labels correct

## Engineering
- [ ] typecheck
- [ ] lint
- [ ] tests
- [ ] no console errors
- [ ] no unnecessary dependencies
- [ ] no duplicated components
- [ ] no dead code

## UX states
- [ ] loading
- [ ] empty
- [ ] error
- [ ] success
- [ ] disabled

## Final question
Would a strong human engineer understand why this implementation exists?
